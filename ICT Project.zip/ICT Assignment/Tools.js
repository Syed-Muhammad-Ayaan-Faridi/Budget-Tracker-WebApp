// Store data
let income = 0;
let expenses = [];

// Get DOM elements
// Using IDs for robust selection
const incomeInput = document.getElementById('monthly-income');
const updateIncomeBtn = document.querySelector('.green-btn');

const expenseNameInput = document.getElementById('expense-name');
const expenseAmountInput = document.getElementById('expense-amount');
const expenseCategoryInput = document.getElementById('expense-category');
const addExpenseBtn = document.querySelector('.blue-btn');

// Summary displays
const totalIncomeDisplay = document.querySelector('.summary-box:nth-child(1) .value');
const totalExpensesDisplay = document.querySelector('.summary-box:nth-child(2) .value');
const remainingDisplay = document.querySelector('.summary-box:nth-child(3) .value');

// Expense list elements
const searchInput = document.querySelector('.search-input');
const sortSelect = document.querySelector('.sort-select');
const emptyText = document.querySelector('.empty-text');
const expensesBox = document.querySelector('.expenses-box');

// Update summary display
function updateSummary() {
    const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
    const remaining = income - totalExpenses;

    totalIncomeDisplay.textContent = '$' + income.toFixed(2);
    totalExpensesDisplay.textContent = '$' + totalExpenses.toFixed(2);
    remainingDisplay.textContent = '$' + remaining.toFixed(2);
}

// Update income
updateIncomeBtn.addEventListener('click', function() {
    const value = parseFloat(incomeInput.value);
    
    if (isNaN(value) || value < 0) {
        alert('Please enter a valid income amount');
        return;
    }
    
    income = value;
    updateSummary();
    incomeInput.value = '';
    alert('Income updated successfully!');
});

// Add expense
addExpenseBtn.addEventListener('click', function() {
    const name = expenseNameInput.value.trim();
    const amount = parseFloat(expenseAmountInput.value);
    const category = expenseCategoryInput.value.trim();
    
    if (name === '') {
        alert('Please enter expense name');
        return;
    }
    
    if (isNaN(amount) || amount <= 0) {
        alert('Please enter a valid amount');
        return;
    }
    
    if (category === '') {
        alert('Please enter a category');
        return;
    }

    // Calculate potential new total expenses
    const currentTotalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
    const newTotalExpenses = currentTotalExpenses + amount;
    const newRemaining = income - newTotalExpenses;

    // Check if the new expense will cause a negative or zero balance
    if (newRemaining < 0) {
        alert('Cannot add expense. This expense of $' + amount.toFixed(2) + ' would result in a negative balance. Remaining budget: $' + (income - currentTotalExpenses).toFixed(2));
        return;
    }
    
    const expense = {
        id: Date.now(),
        name: name,
        amount: amount,
        category: category
    };
    
    expenses.push(expense);
    
    expenseNameInput.value = '';
    expenseAmountInput.value = '';
    expenseCategoryInput.value = '';
    
    updateSummary();
    displayExpenses();
});

// Display expenses
function displayExpenses() {
    // Get search and sort values
    const searchTerm = searchInput.value.toLowerCase();
    const sortValue = sortSelect.value;
    
    // Filter expenses
    let filteredExpenses = expenses.filter(function(expense) {
        return expense.name.toLowerCase().includes(searchTerm) || 
               expense.category.toLowerCase().includes(searchTerm);
    });
    
    // Sort expenses
    if (sortValue === 'name-asc') {
        filteredExpenses.sort(function(a, b) {
            return a.name.localeCompare(b.name);
        });
    } else if (sortValue === 'name-desc') {
        filteredExpenses.sort(function(a, b) {
            return b.name.localeCompare(a.name);
        });
    } else if (sortValue === 'amount-low') {
        filteredExpenses.sort(function(a, b) {
            return a.amount - b.amount;
        });
    } else if (sortValue === 'amount-high') {
        filteredExpenses.sort(function(a, b) {
            return b.amount - a.amount;
        });
    }
    
    // Remove existing expense list
    const existingList = document.querySelector('.expense-list');
    if (existingList) {
        existingList.remove();
    }
    
    // Show or hide empty text
    if (filteredExpenses.length === 0) {
        emptyText.style.display = 'block';
    } else {
        emptyText.style.display = 'none';
    }
    
    // Create expense list
    const expenseList = document.createElement('div');
    expenseList.className = 'expense-list';
    
    filteredExpenses.forEach(function(expense) {
        const expenseItem = document.createElement('div');
        expenseItem.className = 'expense-item';
        
        expenseItem.innerHTML = 
            '<div class="expense-info">' +
                '<h4>' + expense.name + '</h4>' +
                '<p>' + expense.category + '</p>' +
            '</div>' +
            '<div class="expense-actions">' +
                '<span class="expense-amount">$' + expense.amount.toFixed(2) + '</span>' +
                '<button class="delete-btn" data-id="' + expense.id + '">Delete</button>' +
            '</div>';
        
        expenseList.appendChild(expenseItem);
    });
    
    expensesBox.appendChild(expenseList);
    
    // Add delete functionality
    const deleteButtons = document.querySelectorAll('.delete-btn');
    deleteButtons.forEach(function(btn) {
        btn.addEventListener('click', function() {
            const id = parseInt(this.getAttribute('data-id'));
            deleteExpense(id);
        });
    });
}

// Delete expense
function deleteExpense(id) {
    expenses = expenses.filter(function(expense) {
        return expense.id !== id;
    });
    
    updateSummary();
    displayExpenses();
}

// Search functionality
searchInput.addEventListener('input', function() {
    displayExpenses();
});

// Sort functionality
sortSelect.addEventListener('change', function() {
    displayExpenses();
});

// Initialize
updateSummary();
