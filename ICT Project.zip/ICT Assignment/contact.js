// Select the form
const form = document.querySelector("form");

// Listen for submit event
form.addEventListener("submit", function (e) {
    e.preventDefault(); // stop page refresh

    // Get all input values
    const firstName = document.querySelector("input[placeholder='First name']").value.trim();
    const lastName = document.querySelector("input[placeholder='Last name']").value.trim();
    const email = document.querySelector("input[placeholder='Your email']").value.trim();
    const phone = document.querySelector("input[placeholder='Phone number']").value.trim();
    const message = document.querySelector("textarea").value.trim();

    // Empty fields
    if (!firstName || !lastName || !email || !phone || !message) {
        alert("❗ Please fill in all fields.");
        return;
    }

    // Email validation
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        alert("❗ Please enter a valid email address.");
        return;
    }

    // Phone validation (numbers only)
    if (!/^\d+$/.test(phone)) {
        alert("❗ Phone number should contain digits only.");
        return;
    }

    if (phone.length < 7) {
        alert("❗ Phone number is too short.");
        return;
    }

    // If everything is OK
    alert("✅ Your message has been submitted successfully!");

    // Optional: Clear fields
    form.reset();
});
